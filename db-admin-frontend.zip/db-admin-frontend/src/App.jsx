import React, { useState, useEffect } from 'react'
import { fetchTables, fetchSchema } from './services/api'
import Sidebar from './components/Sidebar'
import DataView from './components/DataView'
import SchemaView from './components/SchemaView'

const s = {
  app: { display: 'flex', height: '100vh', overflow: 'hidden', flexDirection: 'column' },
  topbar: {
    display: 'flex',
    alignItems: 'center',
    gap: 12,
    padding: '0 20px',
    height: 46,
    background: 'var(--bg-surface)',
    borderBottom: '1px solid var(--border)',
    flexShrink: 0,
  },
  logo: {
    fontFamily: 'var(--font-mono)',
    fontSize: 13,
    fontWeight: 500,
    color: 'var(--text-primary)',
    letterSpacing: '0.05em',
    display: 'flex',
    alignItems: 'center',
    gap: 8,
  },
  logoMark: {
    width: 22,
    height: 22,
    background: 'var(--accent)',
    borderRadius: 4,
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    fontSize: 12,
    color: '#fff',
    fontWeight: 700,
  },
  divider: { height: 18, width: 1, background: 'var(--border)', margin: '0 4px' },
  tableLabel: {
    fontFamily: 'var(--font-mono)',
    fontSize: 12,
    color: 'var(--text-secondary)',
  },
  tableActive: {
    fontFamily: 'var(--font-mono)',
    fontSize: 12,
    color: 'var(--accent-text)',
  },
  spacer: { flex: 1 },
  refreshBtn: {
    padding: '5px 11px',
    borderRadius: 'var(--radius-sm)',
    border: '1px solid var(--border)',
    background: 'transparent',
    color: 'var(--text-muted)',
    fontSize: 11,
    fontFamily: 'var(--font-mono)',
    cursor: 'pointer',
  },
  body: { display: 'flex', flex: 1, overflow: 'hidden' },
  main: { display: 'flex', flexDirection: 'column', flex: 1, overflow: 'hidden' },
  tabBar: {
    display: 'flex',
    gap: 0,
    padding: '0 16px',
    borderBottom: '1px solid var(--border)',
    background: 'var(--bg-surface)',
    flexShrink: 0,
  },
  tab: (active) => ({
    padding: '9px 16px',
    fontSize: 12,
    fontFamily: 'var(--font-mono)',
    cursor: 'pointer',
    color: active ? 'var(--accent-text)' : 'var(--text-muted)',
    borderBottom: active ? '2px solid var(--accent)' : '2px solid transparent',
    marginBottom: -1,
    background: 'transparent',
    border: 'none',
    borderBottom: active ? '2px solid var(--accent)' : '2px solid transparent',
    transition: 'color var(--transition)',
  }),
  placeholder: {
    flex: 1,
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    flexDirection: 'column',
    gap: 12,
    color: 'var(--text-muted)',
    fontFamily: 'var(--font-mono)',
    fontSize: 12,
  },
  placeholderIcon: {
    fontSize: 32,
    opacity: 0.2,
  },
  errorBanner: {
    margin: 20,
    padding: '12px 16px',
    background: 'var(--danger-dim)',
    border: '1px solid var(--danger)',
    borderRadius: 'var(--radius-md)',
    color: 'var(--danger)',
    fontFamily: 'var(--font-mono)',
    fontSize: 12,
  },
}

export default function App() {
  const [tables,          setTables]          = useState([])
  const [tablesLoading,   setTablesLoading]   = useState(true)
  const [tablesError,     setTablesError]     = useState(null)
  const [selectedTable,   setSelectedTable]   = useState(null)
  const [columns,         setColumns]         = useState([])
  const [columnsLoading,  setColumnsLoading]  = useState(false)
  const [activeTab,       setActiveTab]       = useState('data')

  const loadTables = async () => {
    setTablesLoading(true)
    setTablesError(null)
    try {
      const data = await fetchTables()
      setTables(data)
      // Auto-select first table
      if (data.length > 0 && !selectedTable) {
        selectTable(data[0].tableName)
      }
    } catch (err) {
      setTablesError(err.message)
    } finally {
      setTablesLoading(false)
    }
  }

  const selectTable = async (tableName) => {
    setSelectedTable(tableName)
    setActiveTab('data')
    setColumnsLoading(true)
    try {
      const cols = await fetchSchema(tableName)
      setColumns(cols)
    } catch (err) {
      setColumns([])
    } finally {
      setColumnsLoading(false)
    }
  }

  useEffect(() => { loadTables() }, [])

  const selectedInfo = tables.find((t) => t.tableName === selectedTable)

  return (
    <div style={s.app}>
      {/* Top bar */}
      <header style={s.topbar}>
        <div style={s.logo}>
          <div style={s.logoMark}>DB</div>
          DB Admin
        </div>
        <div style={s.divider} />
        {selectedTable ? (
          <>
            <span style={s.tableLabel}>table /</span>
            <span style={s.tableActive}>{selectedTable}</span>
            {selectedInfo?.tableComment && (
              <span style={{ ...s.tableLabel, fontStyle: 'italic' }}>— {selectedInfo.tableComment}</span>
            )}
          </>
        ) : (
          <span style={s.tableLabel}>Select a table</span>
        )}
        <div style={s.spacer} />
        <button
          style={s.refreshBtn}
          onClick={loadTables}
          onMouseEnter={(e) => (e.target.style.color = 'var(--text-primary)')}
          onMouseLeave={(e) => (e.target.style.color = 'var(--text-muted)')}
        >
          ↻ Refresh
        </button>
      </header>

      {/* Body */}
      <div style={s.body}>
        <Sidebar
          tables={tables}
          loading={tablesLoading}
          selected={selectedTable}
          onSelect={selectTable}
        />

        <div style={s.main}>
          {tablesError && <div style={s.errorBanner}>Failed to load tables: {tablesError}</div>}

          {!selectedTable ? (
            <div style={s.placeholder}>
              <span style={s.placeholderIcon}>▤</span>
              <span>Select a table from the sidebar</span>
            </div>
          ) : columnsLoading ? (
            <div style={s.placeholder}>
              <span className="spin" style={{ fontSize: 18 }}>◌</span>
              <span>Loading schema…</span>
            </div>
          ) : (
            <>
              {/* Tab bar */}
              <div style={s.tabBar}>
                <button style={s.tab(activeTab === 'data')}    onClick={() => setActiveTab('data')}>Data</button>
                <button style={s.tab(activeTab === 'schema')}  onClick={() => setActiveTab('schema')}>Structure</button>
              </div>

              {/* Tab content */}
              {activeTab === 'data' && (
                <DataView
                  key={selectedTable}
                  tableName={selectedTable}
                  columns={columns}
                />
              )}
              {activeTab === 'schema' && (
                <div style={{ flex: 1, overflow: 'auto' }} className="fade-in">
                  <SchemaView columns={columns} />
                </div>
              )}
            </>
          )}
        </div>
      </div>
    </div>
  )
}

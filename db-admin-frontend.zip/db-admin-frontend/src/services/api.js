import axios from 'axios'

const api = axios.create({
  baseURL: '/api/admin/db',
  timeout: 15000,
  headers: { 'Content-Type': 'application/json' },
})

// Unwrap the ApiResponse envelope and surface errors cleanly
api.interceptors.response.use(
  (res) => {
    if (res.data && res.data.success === false) {
      return Promise.reject(new Error(res.data.message || 'Request failed'))
    }
    return res
  },
  (err) => {
    const msg =
      err?.response?.data?.message ||
      err?.message ||
      'Network error'
    return Promise.reject(new Error(msg))
  }
)

// ── Tables ────────────────────────────────────────────────────────────────────
export const fetchTables = () =>
  api.get('/tables').then((r) => r.data.data)

// ── Schema ────────────────────────────────────────────────────────────────────
export const fetchSchema = (table) =>
  api.get(`/tables/${table}/schema`).then((r) => r.data.data)

// ── Rows ──────────────────────────────────────────────────────────────────────
export const fetchRows = (table, { page = 1, pageSize = 20, search = '' } = {}) =>
  api
    .get(`/tables/${table}/rows`, { params: { page, pageSize, search } })
    .then((r) => r.data.data)

export const insertRow = (table, data) =>
  api.post(`/tables/${table}/rows`, { data }).then((r) => r.data)

export const updateRow = (table, pk, data) =>
  api.put(`/tables/${table}/rows/${encodeURIComponent(pk)}`, { data }).then((r) => r.data)

export const deleteRow = (table, pk) =>
  api.delete(`/tables/${table}/rows/${encodeURIComponent(pk)}`).then((r) => r.data)

package com.dbadmin.mapper;

import org.apache.ibatis.annotations.*;

import java.util.List;
import java.util.Map;

/**
 * Dynamic DB admin mapper.
 *
 * NOTE: Table names and column names are injected with ${} (not #{}) because
 * JDBC PreparedStatement cannot parameterise identifiers (table/column names).
 * All table names are validated against the information_schema allow-list in the
 * service layer BEFORE reaching this mapper, preventing SQL injection.
 */
@Mapper
public interface DbAdminMapper {

    // ── Schema discovery ──────────────────────────────────────────────────────

    /**
     * List all base tables in the current schema (excludes views).
     */
    @Select("""
            SELECT
                t.TABLE_NAME        AS tableName,
                t.TABLE_COMMENT     AS tableComment,
                t.TABLE_ROWS        AS rowCount,
                t.ENGINE            AS engine,
                DATE_FORMAT(t.CREATE_TIME, '%Y-%m-%d %H:%i:%s') AS createTime
            FROM information_schema.TABLES t
            WHERE t.TABLE_SCHEMA = DATABASE()
              AND t.TABLE_TYPE   = 'BASE TABLE'
            ORDER BY t.TABLE_NAME
            """)
    List<Map<String, Object>> listTables();

    /**
     * Return column metadata for a specific table.
     * Table name safety: validated in service before this call.
     */
    @Select("""
            SELECT
                c.COLUMN_NAME       AS name,
                c.COLUMN_TYPE       AS type,
                c.IS_NULLABLE       AS nullable,
                c.COLUMN_DEFAULT    AS defaultValue,
                c.EXTRA             AS extra,
                c.COLUMN_KEY        AS keyType,
                c.COLUMN_COMMENT    AS comment
            FROM information_schema.COLUMNS c
            WHERE c.TABLE_SCHEMA = DATABASE()
              AND c.TABLE_NAME   = #{tableName}
            ORDER BY c.ORDINAL_POSITION
            """)
    List<Map<String, Object>> listColumns(@Param("tableName") String tableName);

    /**
     * Confirm a table exists in the current schema (used for validation).
     */
    @Select("""
            SELECT COUNT(*) FROM information_schema.TABLES
            WHERE TABLE_SCHEMA = DATABASE()
              AND TABLE_TYPE   = 'BASE TABLE'
              AND TABLE_NAME   = #{tableName}
            """)
    int tableExists(@Param("tableName") String tableName);

    /**
     * Exact total row count for a table (uses COUNT(*) — reliable for MariaDB).
     */
    @Select("SELECT COUNT(*) FROM `${tableName}`")
    long countRows(@Param("tableName") String tableName);

    /**
     * Exact total row count with a global keyword search across all text-like columns.
     * The WHERE clause is built dynamically in the service and passed as a pre-rendered
     * SQL fragment (already validated/escaped).
     */
    @Select("SELECT COUNT(*) FROM `${tableName}` WHERE ${whereClause}")
    long countRowsWithSearch(@Param("tableName") String tableName,
                             @Param("whereClause") String whereClause);

    // ── Data read ─────────────────────────────────────────────────────────────

    /**
     * Paginated SELECT without search.
     */
    @Select("SELECT * FROM `${tableName}` LIMIT #{limit} OFFSET #{offset}")
    List<Map<String, Object>> selectRows(@Param("tableName") String tableName,
                                         @Param("limit")     int limit,
                                         @Param("offset")    long offset);

    /**
     * Paginated SELECT with a dynamic WHERE clause for search.
     */
    @Select("SELECT * FROM `${tableName}` WHERE ${whereClause} LIMIT #{limit} OFFSET #{offset}")
    List<Map<String, Object>> selectRowsWithSearch(@Param("tableName")  String tableName,
                                                    @Param("whereClause") String whereClause,
                                                    @Param("limit")       int limit,
                                                    @Param("offset")      long offset);

    // ── Data write ────────────────────────────────────────────────────────────

    /**
     * Generic INSERT.
     * columnsSql  → e.g. "`name`, `email`, `role`"
     * valuesSql   → e.g. "#{p0}, #{p1}, #{p2}"   (positional params)
     * values      → the actual value list bound at runtime
     *
     * The service builds these strings and binds a positional param map.
     */
    @Insert("INSERT INTO `${tableName}` (${columnsSql}) VALUES (${valuesSql})")
    @Options(useGeneratedKeys = true, keyColumn = "id")
    int insertRow(@Param("tableName")  String tableName,
                  @Param("columnsSql") String columnsSql,
                  @Param("valuesSql")  String valuesSql,
                  @Param("values")     Map<String, Object> values);

    /**
     * Generic UPDATE by primary key.
     * setSql  → e.g. "`name`=#{values.name}, `email`=#{values.email}"
     * pkCol   → primary key column name (backtick-quoted by service)
     * pkValue → the PK value to match
     */
    @Update("UPDATE `${tableName}` SET ${setSql} WHERE `${pkCol}` = #{pkValue}")
    int updateRow(@Param("tableName") String tableName,
                  @Param("setSql")    String setSql,
                  @Param("pkCol")     String pkCol,
                  @Param("pkValue")   Object pkValue,
                  @Param("values")    Map<String, Object> values);

    /**
     * DELETE by primary key.
     */
    @Delete("DELETE FROM `${tableName}` WHERE `${pkCol}` = #{pkValue}")
    int deleteRow(@Param("tableName") String tableName,
                  @Param("pkCol")     String pkCol,
                  @Param("pkValue")   Object pkValue);
}

package com.dbadmin.config;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

import java.util.List;

@Data
@Component
@ConfigurationProperties(prefix = "db-admin")
public class DbAdminProperties {

    /** Hard cap on rows per page */
    private int maxPageSize = 200;

    /** Tables that must never be exposed via the admin panel */
    private List<String> blockedTables = List.of(
            "flyway_schema_history",
            "DATABASECHANGELOG",
            "DATABASECHANGELOGLOCK"
    );

    public boolean isTableBlocked(String tableName) {
        return blockedTables.stream()
                .anyMatch(t -> t.equalsIgnoreCase(tableName));
    }
}

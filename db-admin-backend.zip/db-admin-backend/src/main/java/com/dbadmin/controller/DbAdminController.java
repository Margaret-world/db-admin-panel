package com.dbadmin.controller;

import com.dbadmin.model.request.RowRequest;
import com.dbadmin.model.response.ApiResponse;
import com.dbadmin.model.response.ColumnMeta;
import com.dbadmin.model.response.PageResult;
import com.dbadmin.model.response.TableInfo;
import com.dbadmin.service.DbAdminService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * DB Admin Panel REST API
 *
 * Base path: /api/admin/db
 *
 * Endpoints:
 *   GET    /tables                        → list all tables
 *   GET    /tables/{table}/schema         → column definitions
 *   GET    /tables/{table}/rows           → paginated rows (+ search)
 *   POST   /tables/{table}/rows           → insert a new row
 *   PUT    /tables/{table}/rows/{pk}      → update a row by PK
 *   DELETE /tables/{table}/rows/{pk}      → delete a row by PK
 */
@RestController
@RequestMapping("/api/admin/db")
@RequiredArgsConstructor
public class DbAdminController {

    private final DbAdminService service;

    // ── Tables ────────────────────────────────────────────────────────────────

    /**
     * List all base tables in the connected database.
     *
     * GET /api/admin/db/tables
     */
    @GetMapping("/tables")
    public ApiResponse<List<TableInfo>> listTables() {
        return ApiResponse.ok(service.listTables());
    }

    // ── Schema ────────────────────────────────────────────────────────────────

    /**
     * Return column definitions for a specific table.
     *
     * GET /api/admin/db/tables/{table}/schema
     */
    @GetMapping("/tables/{table}/schema")
    public ApiResponse<List<ColumnMeta>> getSchema(@PathVariable("table") String table) {
        return ApiResponse.ok(service.listColumns(table));
    }

    // ── Rows ──────────────────────────────────────────────────────────────────

    /**
     * Paginated row listing with optional global search.
     *
     * GET /api/admin/db/tables/{table}/rows
     *     ?page=1&pageSize=20&search=keyword
     */
    @GetMapping("/tables/{table}/rows")
    public ApiResponse<PageResult> listRows(
            @PathVariable("table") String table,
            @RequestParam(defaultValue = "1")  int page,
            @RequestParam(defaultValue = "20") int pageSize,
            @RequestParam(defaultValue = "")   String search) {
        return ApiResponse.ok(service.listRows(table, page, pageSize, search));
    }

    /**
     * Insert a new row.
     *
     * POST /api/admin/db/tables/{table}/rows
     * Body: { "data": { "col1": "val1", "col2": "val2" } }
     */
    @PostMapping("/tables/{table}/rows")
    public ApiResponse<Void> insertRow(
            @PathVariable("table") String table,
            @Valid @RequestBody RowRequest request) {
        service.insertRow(table, request.getData());
        return ApiResponse.ok("Row inserted successfully", null);
    }

    /**
     * Update an existing row identified by its primary key.
     *
     * PUT /api/admin/db/tables/{table}/rows/{pk}
     * Body: { "data": { "col1": "newVal" } }
     */
    @PutMapping("/tables/{table}/rows/{pk}")
    public ApiResponse<Void> updateRow(
            @PathVariable("table") String table,
            @PathVariable("pk")    String pk,
            @Valid @RequestBody RowRequest request) {
        service.updateRow(table, pk, request.getData());
        return ApiResponse.ok("Row updated successfully", null);
    }

    /**
     * Delete a row by its primary key value.
     *
     * DELETE /api/admin/db/tables/{table}/rows/{pk}
     */
    @DeleteMapping("/tables/{table}/rows/{pk}")
    public ApiResponse<Void> deleteRow(
            @PathVariable("table") String table,
            @PathVariable("pk")    String pk) {
        service.deleteRow(table, pk);
        return ApiResponse.ok("Row deleted successfully", null);
    }
}

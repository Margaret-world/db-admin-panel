package com.dbadmin.service;

import com.dbadmin.config.DbAdminProperties;
import com.dbadmin.exception.AdminException;
import com.dbadmin.mapper.DbAdminMapper;
import com.dbadmin.model.response.ColumnMeta;
import com.dbadmin.model.response.PageResult;
import com.dbadmin.model.response.TableInfo;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

@Slf4j
@Service
@RequiredArgsConstructor
public class DbAdminService {

    private final DbAdminMapper mapper;
    private final DbAdminProperties props;

    // ── Tables ────────────────────────────────────────────────────────────────

    public List<TableInfo> listTables() {
        return mapper.listTables().stream()
                .filter(row -> !props.isTableBlocked((String) row.get("tableName")))
                .map(row -> TableInfo.builder()
                        .tableName((String) row.get("tableName"))
                        .tableComment(nullToEmpty(row.get("tableComment")))
                        .rowCount(toLong(row.get("rowCount")))
                        .engine(nullToEmpty(row.get("engine")))
                        .createTime(nullToEmpty(row.get("createTime")))
                        .build())
                .collect(Collectors.toList());
    }

    // ── Schema ────────────────────────────────────────────────────────────────

    public List<ColumnMeta> listColumns(String tableName) {
        validateTable(tableName);
        return mapper.listColumns(tableName).stream()
                .map(row -> ColumnMeta.builder()
                        .name((String) row.get("name"))
                        .type((String) row.get("type"))
                        .primaryKey("PRI".equals(row.get("keyType")))
                        .nullable("YES".equals(row.get("nullable")))
                        .defaultValue(nullToEmpty(row.get("defaultValue")))
                        .extra(nullToEmpty(row.get("extra")))
                        .keyType(nullToEmpty(row.get("keyType")))
                        .comment(nullToEmpty(row.get("comment")))
                        .build())
                .collect(Collectors.toList());
    }

    // ── Rows — read ───────────────────────────────────────────────────────────

    public PageResult listRows(String tableName, int page, int pageSize, String search) {
        validateTable(tableName);

        // Enforce hard cap
        pageSize = Math.min(pageSize, props.getMaxPageSize());
        if (pageSize < 1) pageSize = 20;
        if (page < 1) page = 1;
        long offset = (long) (page - 1) * pageSize;

        long total;
        List<Map<String, Object>> rows;

        if (StringUtils.hasText(search)) {
            // Build a LIKE search across all text-compatible columns
            String whereClause = buildSearchWhereClause(tableName, search.trim());
            total = mapper.countRowsWithSearch(tableName, whereClause);
            rows  = mapper.selectRowsWithSearch(tableName, whereClause, pageSize, offset);
        } else {
            total = mapper.countRows(tableName);
            rows  = mapper.selectRows(tableName, pageSize, offset);
        }

        int totalPages = (int) Math.ceil((double) total / pageSize);
        return PageResult.builder()
                .total(total)
                .page(page)
                .pageSize(pageSize)
                .totalPages(totalPages)
                .rows(rows)
                .build();
    }

    // ── Rows — write ──────────────────────────────────────────────────────────

    @Transactional
    public void insertRow(String tableName, Map<String, Object> data) {
        validateTable(tableName);
        if (data == null || data.isEmpty()) {
            throw new AdminException("Row data must not be empty");
        }

        // Validate column names against actual schema to prevent injection
        Set<String> validCols = getValidColumnNames(tableName);
        Map<String, Object> safe = filterToValidColumns(data, validCols);
        if (safe.isEmpty()) {
            throw new AdminException("No valid columns provided");
        }

        List<String> cols   = new ArrayList<>(safe.keySet());
        List<Object> vals   = cols.stream().map(safe::get).toList();

        String columnsSql = cols.stream().map(c -> "`" + c + "`").collect(Collectors.joining(", "));
        String valuesSql  = IntStream.range(0, cols.size())
                .mapToObj(i -> "#{values.v" + i + "}")
                .collect(Collectors.joining(", "));

        // Build a positional value map (v0, v1, v2 …)
        Map<String, Object> valueMap = new LinkedHashMap<>();
        IntStream.range(0, vals.size()).forEach(i -> valueMap.put("v" + i, vals.get(i)));

        int affected = mapper.insertRow(tableName, columnsSql, valuesSql, valueMap);
        if (affected == 0) throw new AdminException("Insert failed — no rows affected");
        log.info("[db-admin] INSERT into {} ({} columns)", tableName, cols.size());
    }

    @Transactional
    public void updateRow(String tableName, Object pkValue, Map<String, Object> data) {
        validateTable(tableName);
        if (data == null || data.isEmpty()) {
            throw new AdminException("Row data must not be empty");
        }

        String pkCol = getPrimaryKeyColumn(tableName);

        Set<String> validCols = getValidColumnNames(tableName);
        Map<String, Object> safe = filterToValidColumns(data, validCols);
        // Never allow updating the PK
        safe.remove(pkCol);
        if (safe.isEmpty()) {
            throw new AdminException("No updatable columns provided");
        }

        List<String> cols = new ArrayList<>(safe.keySet());
        String setSql = cols.stream()
                .map(c -> "`" + c + "`=#{values." + c + "}")
                .collect(Collectors.joining(", "));

        int affected = mapper.updateRow(tableName, setSql, pkCol, pkValue, safe);
        if (affected == 0) throw new AdminException("Update failed — row not found or no change");
        log.info("[db-admin] UPDATE {} pk={}", tableName, pkValue);
    }

    @Transactional
    public void deleteRow(String tableName, Object pkValue) {
        validateTable(tableName);
        String pkCol = getPrimaryKeyColumn(tableName);
        int affected = mapper.deleteRow(tableName, pkCol, pkValue);
        if (affected == 0) throw new AdminException("Delete failed — row not found");
        log.info("[db-admin] DELETE from {} pk={}", tableName, pkValue);
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    /**
     * Validate the table name:
     * 1. Not blocked by config
     * 2. Exists in the current database schema (prevents injection via fabricated names)
     */
    private void validateTable(String tableName) {
        if (!StringUtils.hasText(tableName)) {
            throw new AdminException("Table name must not be blank");
        }
        if (props.isTableBlocked(tableName)) {
            throw new AdminException("Access to table '" + tableName + "' is not permitted");
        }
        if (mapper.tableExists(tableName) == 0) {
            throw new AdminException("Table '" + tableName + "' does not exist");
        }
    }

    private Set<String> getValidColumnNames(String tableName) {
        return mapper.listColumns(tableName).stream()
                .map(c -> (String) c.get("name"))
                .collect(Collectors.toSet());
    }

    private String getPrimaryKeyColumn(String tableName) {
        return mapper.listColumns(tableName).stream()
                .filter(c -> "PRI".equals(c.get("keyType")))
                .map(c -> (String) c.get("name"))
                .findFirst()
                .orElseThrow(() -> new AdminException("No primary key found on table '" + tableName + "'"));
    }

    /**
     * Build a WHERE clause that searches all character-type columns with LIKE.
     * Column names are taken from information_schema (trusted), then backtick-quoted.
     * The search term is escaped to neutralise % _ and \ wildcards.
     */
    private String buildSearchWhereClause(String tableName, String search) {
        String escapedSearch = search
                .replace("\\", "\\\\")
                .replace("%", "\\%")
                .replace("_", "\\_");
        String likeVal = "%" + escapedSearch + "%";

        List<String> conditions = mapper.listColumns(tableName).stream()
                .filter(c -> isTextCompatible((String) c.get("type")))
                .map(c -> "`" + c.get("name") + "` LIKE '" + likeVal.replace("'", "\\'") + "'")
                .collect(Collectors.toList());

        if (conditions.isEmpty()) {
            // Fallback — no text columns; return a no-op so SQL stays valid
            return "1=0";
        }
        return String.join(" OR ", conditions);
    }

    private boolean isTextCompatible(String colType) {
        if (colType == null) return false;
        String t = colType.toLowerCase();
        return t.startsWith("varchar") || t.startsWith("char")
                || t.startsWith("text") || t.startsWith("tinytext")
                || t.startsWith("mediumtext") || t.startsWith("longtext")
                || t.startsWith("enum") || t.startsWith("set")
                || t.startsWith("int") || t.startsWith("bigint")
                || t.startsWith("decimal") || t.startsWith("float")
                || t.startsWith("double") || t.startsWith("date")
                || t.startsWith("datetime") || t.startsWith("timestamp");
    }

    private Map<String, Object> filterToValidColumns(Map<String, Object> data, Set<String> validCols) {
        Map<String, Object> result = new LinkedHashMap<>();
        data.forEach((k, v) -> {
            if (validCols.contains(k)) result.put(k, v);
        });
        return result;
    }

    private String nullToEmpty(Object val) {
        return val == null ? "" : val.toString();
    }

    private long toLong(Object val) {
        if (val == null) return 0L;
        if (val instanceof Number n) return n.longValue();
        try { return Long.parseLong(val.toString()); } catch (Exception e) { return 0L; }
    }
}
